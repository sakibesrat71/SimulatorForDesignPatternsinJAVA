public class CountingDuck extends DuckDecorator{

    public CountingDuck(Quackable duck) {
        super(duck);
    }

    public void quack() {
        duck.quack();
        incrementCounter();

    }
    public  int counter = 0;
    public void incrementCounter() {
        counter++;
        System.out.println("Quack counter: " + counter);
    }
}
