import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.swing.*;

public class Duck implements Quackable {

    NotificationService notificationService = new NotificationService();
    public void quack() {
        System.out.println("Quack");
        playQuackSound("quack.wav");
        notificationService.notifyListeners();

    }
   
}


