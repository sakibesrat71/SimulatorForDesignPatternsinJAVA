import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.swing.*;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;

public class Goose implements Honkable {
    public void honk() {
        System.out.println("Honk");
        playHonkSound("honk.wav");
    }

//
}
