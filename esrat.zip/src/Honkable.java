public interface Honkable {
    public void honk();
}
