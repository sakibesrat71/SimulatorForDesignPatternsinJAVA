public class MallardDuck implements Quackable {

    String name;

    // constructor
    public MallardDuck(String name) {
        this.name = name;
    }

    public void quack() {
        System.out.println(name + "Quack");
    }
}

