import java.util.ArrayList;
import java.util.List;

public class NotificationService {
    private List<Listeners> listeners = new ArrayList<Listeners>();

    public void addListener(Listeners listener) {
        listeners.add(listener);
    }

    public void removeListener(Listeners listener) {
        listeners.remove(listener);
    }

    public void notifyListeners() {
        for (Listeners listener : listeners) {
            listener.onEvent();
        }
    }

}
